// VideoCall.js
import React from 'react';
import './VideoCall.css';

const VideoCall = () => {
    return (
        <div className="video-call">
            <h2>Video Call</h2>
            <div className="video-screen">
                <p>Video will appear here...</p>
            </div>
            <button className="end-call-button">End Call</button>
        </div>
    );
};

export default VideoCall;

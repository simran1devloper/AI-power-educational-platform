// GroupChat.js
import React, { useState } from 'react';
import './GroupChat.css';

const GroupChat = () => {
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');

    const handleSendMessage = () => {
        setMessages([...messages, { text: input, sender: 'user' }]);
        setInput('');
    };

    return (
        <div className="group-chat">
            <h2>Group Chat</h2>
            <div className="messages">
                {messages.map((msg, index) => (
                    <div key={index} className={`message ${msg.sender}`}>
                        {msg.text}
                    </div>
                ))}
            </div>
            <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type a message"
            />
            <button onClick={handleSendMessage}>Send</button>
        </div>
    );
};

export default GroupChat;
